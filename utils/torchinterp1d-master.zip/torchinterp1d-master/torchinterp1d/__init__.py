from .interp1d import interp1d, Interp1d
